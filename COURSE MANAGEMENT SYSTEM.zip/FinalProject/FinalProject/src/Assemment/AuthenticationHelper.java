package Assemment;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AuthenticationHelper {
	 //for login
    public static boolean doesUserExist(String email, String password) {
        String query = "SELECT * FROM finalAssemment.person WHERE email = ? AND password = ?";
        
        try (Connection conn = ConnectionHelper.createConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, email);
            pstmt.setString(2, password);

            try (ResultSet rs = pstmt.executeQuery()) {
                return rs.next();  // Returns true if the user exists, false otherwise
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // get user role
    public static String getUserRole(String email) {
        String query = "SELECT role FROM finalAssemment.person WHERE email = ?";
        
        try (Connection conn = ConnectionHelper.createConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, email);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getString("role");  // Returns the role of the user
                } else {
                    return null;  // User not found
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    //for register
    public static boolean isEmailAlreadyRegistered(String email) {
        String query = "SELECT * FROM finalAssemment.person WHERE email = ?";
        
        try (Connection conn = ConnectionHelper.createConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, email);

            try (ResultSet rs = pstmt.executeQuery()) {
                return rs.next();  // Returns true if the email is already registered, false otherwise
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    //check if the email is a valid one
    public static boolean isValidEmail(String email) {
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        Pattern pattern = Pattern.compile(emailRegex);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }
    
    //check if all the fields are not empty
    public static boolean isEmpty(String value) {
        return value == null || value.isEmpty();
    }
    
    public static String getUserName(String email) {
        String query = "SELECT name FROM finalAssemment.person WHERE email = ?";

        try (Connection conn = ConnectionHelper.createConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, email);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getString("name");  // Returns the name of the user
                } else {
                    return null;  // User not found
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    //validate all the fields
    public static boolean validateInput(String userName, String email, String password, String confirmPassword) {
        if (AuthenticationHelper.isEmpty(userName)) {
            Message.showErrorMessage("Name is required");
            return false;
        }

        if (AuthenticationHelper.isEmpty(email) || !AuthenticationHelper.isValidEmail(email)) {
            Message.showErrorMessage("Invalid email format");
            return false;
        }

        if (AuthenticationHelper.isEmpty(password)) {
            Message.showErrorMessage("Password is required");
            return false;
        }

        if (password.length() < 4) {
            Message.showErrorMessage("Password length must be more than 4");
            return false;
        }

        if (AuthenticationHelper.isEmpty(confirmPassword)) {
            Message.showErrorMessage("Confirm Password is required");
            return false;
        }

        if (!confirmPassword.equals(password)) {
            Message.showErrorMessage("Password and Confirm Password do not match");
            return false;
        }

        return true;
    }
    
    //get the course id for the selected course
    public static int getCourseIdForSelectedCourse(String selectedCourse) {
        int courseId = -1; // Default value in case the course is not found or an error occurs
        try (Connection conn = ConnectionHelper.createConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT course_id FROM finalAssemment.course WHERE course_name = '" + selectedCourse + "'")) {

            if (rs.next()) {
                courseId = rs.getInt("course_id");
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return courseId;
    }

}
