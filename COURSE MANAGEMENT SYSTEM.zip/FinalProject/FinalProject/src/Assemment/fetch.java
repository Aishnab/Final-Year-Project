package Assemment;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class fetch {
	// fetch the student table data model
	public static DefaultTableModel getStudentDataModel() {
	    DefaultTableModel model = new DefaultTableModel();
	    model.addColumn("Student ID");
	    model.addColumn("Name");
	    model.addColumn("Course");

	    String selectStudentsSQL = "SELECT student_id, person_id, course_id FROM finalAssemment.student";

	    try (Connection connection = ConnectionHelper.createConnection();
	         PreparedStatement statement = connection.prepareStatement(selectStudentsSQL);
	         ResultSet resultSet = statement.executeQuery()) {

	        while (resultSet.next()) {
	            int studentId = resultSet.getInt("student_id");
	            int personId = resultSet.getInt("person_id");
	            int courseId = resultSet.getInt("course_id");
	            String name = getStudentName(personId); 
	            String course = getCourseName(courseId);
	            model.addRow(new Object[]{studentId, name, course});
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	        JOptionPane.showMessageDialog(null, "Error fetching student data", "Error", JOptionPane.ERROR_MESSAGE);
	    }

	    return model;
	}
	
	
 //fetch the student name
	public static String getStudentName(int personId) {
	    String studentName = "";
	 
	    String selectStudentNameSQL = "SELECT name FROM finalAssemment.person WHERE person_id = ?";

	    try (Connection connection = ConnectionHelper.createConnection();
	         PreparedStatement statement = connection.prepareStatement(selectStudentNameSQL)) {

	        statement.setInt(1, personId);
	        ResultSet resultSet = statement.executeQuery();

	        if (resultSet.next()) {
	            studentName = resultSet.getString("name");
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	        JOptionPane.showMessageDialog(null, "Error fetching student name", "Error", JOptionPane.ERROR_MESSAGE);
	    }

	    return studentName;
	}

	//fetch the student course Name
	public static String getCourseName(int courseId) {
	    String courseName = "";
	 
	    String selectCourseNameSQL = "SELECT course_name FROM finalAssemment.course WHERE course_id = ?";

	    try (Connection connection = ConnectionHelper.createConnection();
	         PreparedStatement statement = connection.prepareStatement(selectCourseNameSQL)) {

	        statement.setInt(1, courseId);
	        ResultSet resultSet = statement.executeQuery();

	        if (resultSet.next()) {
	            courseName = resultSet.getString("course_name");
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	        JOptionPane.showMessageDialog(null, "Error fetching course name", "Error", JOptionPane.ERROR_MESSAGE);
	    }

	    return courseName;
	}
}
