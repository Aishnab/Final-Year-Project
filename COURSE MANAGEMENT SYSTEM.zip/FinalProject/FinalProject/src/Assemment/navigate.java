package Assemment;

import javax.swing.JFrame;

public class navigate {
	
public static void navigateToDashboard() {
	Dashboard dashboard = new Dashboard();
	dashboard.setVisible(true);
}

public static void navigateToCourse() {
Course course = new Course();
course.setVisible(true);
}

public static void navigateToTeacher() {
	Teacher teacher  = new Teacher();
	teacher.setVisible(true);
}

public static void navigateToStudents() {
Student student = new Student();
student.setVisible(true);
}

public static void navigateToLogin() {
Login login = new Login();
login.setVisible(true);
}

public static void navigateToRegister() {
Register register = new Register();
register.setVisible(true);
}

public static void navigateToGradeStudent() {
gradeStudent grade = new gradeStudent();
grade.setVisible(true);
}

public static void navigateToStudentReport() {
showStudentReport showReport = new showStudentReport();
showReport.setVisible(true);
}

public static void navigateToAddStudent() {
addStudent addS = new addStudent();
addS.setVisible(true);
}

public static void navigateToAssignModule() {
assignModule assign = new assignModule();
assign.setVisible(true);
}

public static void navigateToAddTeacher() {
addTeacher addTeacher1 = new addTeacher();
addTeacher1.setVisible(true);
}

public static void navigateToResultSlipGenerator() {
	resultSlipGenerator obj1 = new resultSlipGenerator();
obj1.setVisible(true);
}






}
