package Assemment;

public class UserInfo {
	
	 private static String userName;
	 private static String userRole;

     //get the user name
	    public static String getUserName() {
	        return userName;
	    }

	    public static void setUserName(String userName) {
	        UserInfo.userName = userName;
	    }
	   
	   //to get the user role
	    public static String getUserRole() {
	        return userRole;
	    }

	    public static void setUserRole(String userRole) {
	        UserInfo.userRole = userRole;
	    }
	  
}
