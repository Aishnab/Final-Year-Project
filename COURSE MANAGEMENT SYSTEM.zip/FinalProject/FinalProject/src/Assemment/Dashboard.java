package Assemment;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.JList;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class Dashboard extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	 
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Dashboard frame = new Dashboard();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	
	
	   
	public Dashboard() {
		
		if(UserInfo.getUserName()== null) {
			dispose();
			navigate.navigateToLogin();
			return;
		}
		  
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 890, 496);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Welcome "+UserInfo.getUserName());
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel.setBounds(27, 47, 226, 14);
		contentPane.add(lblNewLabel);
		
		JList list = new JList();
		list.setBounds(107, 254, 271, 0);
		contentPane.add(list);
		 
		 JButton btnNewButton = new JButton("Courses");
		 btnNewButton.addActionListener(new ActionListener() {
		 	public void actionPerformed(ActionEvent e) {
		 		 navigate.navigateToCourse();
		 		 dispose();
		 	}
		 });
		 btnNewButton.setBounds(357, 7, 89, 23);
		 contentPane.add(btnNewButton);
		 
		
		 
		 JButton btnNewButton_2 = new JButton("Tutors");
		 btnNewButton_2.setBounds(461, 7, 89, 23);
		 contentPane.add(btnNewButton_2);
		 btnNewButton_2.addActionListener(new ActionListener() {
			 	public void actionPerformed(ActionEvent e) {
			 		 navigate.navigateToTeacher();
			 		 dispose();
			 	}
			 });
		 
		 
		 JButton btnNewButton_2_1 = new JButton("Students");
		 btnNewButton_2_1.setBounds(560, 7, 89, 23);
		 contentPane.add(btnNewButton_2_1);
		 btnNewButton_2_1.addActionListener(new ActionListener() {
			 	public void actionPerformed(ActionEvent e) {
			 		 navigate.navigateToStudents();
			 		 dispose();
			 	}
			 });
		 
		 JLabel lblNewLabel_3 = new JLabel("Dashboard");
		 lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 18));
		 lblNewLabel_3.setBounds(27, 4, 114, 32);
		 contentPane.add(lblNewLabel_3);
		 
		 JLabel lblLoggedInAs = new JLabel("Logged In As " + UserInfo.getUserRole());
		 lblLoggedInAs.setFont(new Font("Tahoma", Font.PLAIN, 14));
		 lblLoggedInAs.setBounds(27, 64, 226, 23);
		 contentPane.add(lblLoggedInAs);
		 
		 JLabel lblNewLabel_1 = new JLabel("Total Student : " + getCount("Student"));
		 lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		 lblNewLabel_1.setBounds(27, 179, 284, 14);
		 contentPane.add(lblNewLabel_1);
		 
		 JLabel lblNewLabel_1_1 = new JLabel("Total Teacher: " + getCount("Teacher"));
		 lblNewLabel_1_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		 lblNewLabel_1_1.setBounds(27, 204, 284, 14);
		 contentPane.add(lblNewLabel_1_1);
		 
		 
		 JLabel lblNewLabel_1_1_1 = new JLabel("Total Course: " + getCount("course"));
		 lblNewLabel_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		 lblNewLabel_1_1_1.setBounds(27, 240, 284, 14);
		 contentPane.add(lblNewLabel_1_1_1);
		 
		
		
	}
	
	
		
		public  int getCount(String tableName) {
	        String query = "SELECT COUNT(*) AS count FROM " + tableName;

	        try (Connection conn = ConnectionHelper.createConnection();
	             PreparedStatement pstmt = conn.prepareStatement(query);
	             ResultSet rs = pstmt.executeQuery()) {

	            if (rs.next()) {
	                return rs.getInt("count");
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }

	        return 0;  
	    }
	  
}
