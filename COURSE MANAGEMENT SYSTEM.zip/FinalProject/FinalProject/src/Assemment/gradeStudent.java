package Assemment;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.sql.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class gradeStudent extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JComboBox<String> studentComboBox;
    private JComboBox<String> moduleComboBox;
    private JTextField textField;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    gradeStudent frame = new gradeStudent();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public gradeStudent() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 450, 300);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblNewLabel = new JLabel("Select Student:");
        lblNewLabel.setBounds(20, 30, 100, 14);
        contentPane.add(lblNewLabel);

        studentComboBox = new JComboBox<>();
        studentComboBox.setBounds(130, 27, 200, 20);
        contentPane.add(studentComboBox);

        JLabel lblNewLabel_1 = new JLabel("Select Module:");
        lblNewLabel_1.setBounds(20, 70, 100, 14);
        contentPane.add(lblNewLabel_1);

        moduleComboBox = new JComboBox<>();
        moduleComboBox.setBounds(130, 67, 200, 20);
        contentPane.add(moduleComboBox);

        JLabel lblNewLabel_2 = new JLabel("Percentage");
        lblNewLabel_2.setBounds(20, 110, 100, 14);
        contentPane.add(lblNewLabel_2);

        JButton btnGrade = new JButton("Grade");
        btnGrade.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                gradeStudent();
            }
        });
        btnGrade.setBounds(130, 170, 100, 23);
        contentPane.add(btnGrade);
        
        JButton btnNewButton = new JButton("Back");
        btnNewButton.setBounds(269, 170, 89, 23);
        contentPane.add(btnNewButton);
        
        textField = new JTextField();
        textField.setBounds(130, 107, 200, 20);
        contentPane.add(textField);
        textField.setColumns(10);
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
               navigate.navigateToStudents();
               dispose();
            }
        });

        studentComboBox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Get the selected student's ID
                String selectedStudent = (String) studentComboBox.getSelectedItem();
                int studentId = Integer.parseInt(selectedStudent.split(" - ")[0]);
                
                // Fetch the course ID associated with the selected student
                int courseId = fetchCourseIdForStudent(studentId); 
                
                // Populate the module combo box based on the course ID
                populateModuleComboBox(courseId);
            }
        });
        
        populateStudentComboBox();
       
    }

    private void populateStudentComboBox() {
        try (Connection connection = ConnectionHelper.createConnection()) {
            String studentQuery = "SELECT student_id, person_id FROM finalAssemment.student";
            PreparedStatement studentStatement = connection.prepareStatement(studentQuery);
            ResultSet studentResultSet = studentStatement.executeQuery();

            while (studentResultSet.next()) {
                int studentId = studentResultSet.getInt("student_id");
                int personId = studentResultSet.getInt("person_id");
                String studentName = getStudentName(connection, personId);
                studentComboBox.addItem(studentId + " - " + studentName);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error fetching student data", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private String getStudentName(Connection connection, int personId) throws SQLException {
        String query = "SELECT name FROM finalAssemment.person WHERE person_id = ?";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setInt(1, personId);
        ResultSet resultSet = statement.executeQuery();
        return resultSet.next() ? resultSet.getString("name") : null;
    }

    private void gradeStudent() {
        String selectedStudent = (String) studentComboBox.getSelectedItem();
        String selectedModule = (String) moduleComboBox.getSelectedItem();
        double selectedPercentage = Double.parseDouble(textField.getText());

        // Extract student ID and module ID from the selected strings
        int studentId = Integer.parseInt(selectedStudent.split(" - ")[0]);
        int moduleId = Integer.parseInt(selectedModule.split(" - ")[0]);

        try (Connection connection = ConnectionHelper.createConnection()) {
            // Calculate grade value based on percentage (not shown here)
            String calculatedGrade = calculateGrade(selectedPercentage);

            String insertQuery = "INSERT INTO finalAssemment.grade (teacher_id, student_id, module_id, grade_value, percentage) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(insertQuery);
            statement.setInt(1, 1); // Replace with the actual teacher's ID
            statement.setInt(2, studentId);
            statement.setInt(3, moduleId);
            statement.setString(4, calculatedGrade);
            statement.setDouble(5, selectedPercentage);

            int rowsAffected = statement.executeUpdate();

            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(null, "Student graded successfully", "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Failed to grade student", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error grading student", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    
    private void populateModuleComboBox(int courseId) {
    	   moduleComboBox.removeAllItems(); // Clear the combo box
        try (Connection connection = ConnectionHelper.createConnection()) {
            String moduleQuery = "SELECT module_id, module_name FROM finalAssemment.modules WHERE course_id = ?";
            PreparedStatement moduleStatement = connection.prepareStatement(moduleQuery);
            moduleStatement.setInt(1, courseId);
            ResultSet moduleResultSet = moduleStatement.executeQuery();

            while (moduleResultSet.next()) {
                int moduleId = moduleResultSet.getInt("module_id");
                String moduleName = moduleResultSet.getString("module_name");
                moduleComboBox.addItem(moduleId + " - " + moduleName);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error fetching module data", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    private int fetchCourseIdForStudent(int studentId) {
        int courseId = -1; // Default value if courseId is not found
        try (Connection connection = ConnectionHelper.createConnection()) {
            String courseIdQuery = "SELECT course_id FROM finalAssemment.student WHERE student_id = ?";
            PreparedStatement statement = connection.prepareStatement(courseIdQuery);
            statement.setInt(1, studentId);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                courseId = resultSet.getInt("course_id");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error fetching course ID for student", "Error", JOptionPane.ERROR_MESSAGE);
        }
        return courseId;
    }
    
    private String calculateGrade(double percentage) {
        // Implement logic to calculate grade from percentage
        // This is just a placeholder method, replace it with your actual logic
        if (percentage >= 90) {
            return "A+";
        } else if (percentage >= 80) {
            return "A";
        } else if (percentage >= 70) {
            return "B+";
        } else if (percentage >= 60) {
            return "B";
        } else if (percentage >= 50) {
            return "C+";
        } else if (percentage >= 40) {
            return "C";
        } else if (percentage >= 30) {
            return "D+";
        } else if (percentage >= 20) {
            return "D";
        } else {
            return "E";
        }
    }
}
