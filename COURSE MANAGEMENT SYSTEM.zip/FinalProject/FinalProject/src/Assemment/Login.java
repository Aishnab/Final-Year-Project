package Assemment;
import java.awt.EventQueue;


import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.JOptionPane;

import java.sql.*;

public class Login extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;


	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 923, 498);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Login Page");
		lblNewLabel.setFont(new Font("Times New Roman", Font.PLAIN, 24));
		lblNewLabel.setBounds(417, 101, 148, 25);
		contentPane.add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(371, 168, 213, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Email");
		lblNewLabel_1.setBounds(295, 171, 46, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Password");
		lblNewLabel_2.setBounds(293, 201, 70, 17);
		contentPane.add(lblNewLabel_2);
		
		textField_1 = new JTextField();
		textField_1.setBounds(371, 199, 213, 20);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		JButton btnNewButton = new JButton("Login");
		btnNewButton.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        String email = textField.getText();
		        String password = textField_1.getText();
		        
		        if (AuthenticationHelper.doesUserExist(email, password)) {
		        	
		        	 String userName = AuthenticationHelper.getUserName(email);
		        	 String userRole = AuthenticationHelper.getUserRole(email);
		        	 UserInfo.setUserName(userName);
		        	 UserInfo.setUserRole(userRole);
		        	  
		        	 Dashboard dashboard = new Dashboard();        
		             dashboard.setVisible(true);
		             dispose();  // Close the login window
		             
		        } else {
		            // Check if the email exists in the database
		            if (AuthenticationHelper.isEmailAlreadyRegistered(email)) {
		                Message.showErrorMessage("Incorrect password. Please try again.");
		            } else {
		                Message.showErrorMessage("Email not registered. Please login.");
		            }
		        }
		    }
             
		    }
		);

		
		btnNewButton.setBounds(371, 242, 213, 25);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Register");
		btnNewButton_1.setBounds(371, 278, 213, 23);
		contentPane.add(btnNewButton_1);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				navigate.navigateToRegister();
				dispose();
			}
		});
		
		
	}
}

