package Assemment;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class showStudentReport extends JFrame {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
    private JTextField textField;
    private JTable table_1;
    private JLabel lblStudentName;
    private JLabel lblCourse;

    public showStudentReport() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 672, 490);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblNewLabel = new JLabel("Student Progress Report");
        lblNewLabel.setBounds(20, 34, 198, 14);
        lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
        contentPane.add(lblNewLabel);

        JLabel lblNewLabel_1 = new JLabel("Student Name:");
        lblNewLabel_1.setBounds(20, 83, 136, 14);
        contentPane.add(lblNewLabel_1);

        JLabel lblNewLabel_1_1 = new JLabel("Course:");
        lblNewLabel_1_1.setBounds(20, 117, 136, 14);
        contentPane.add(lblNewLabel_1_1);

        lblStudentName = new JLabel("");
        lblStudentName.setBounds(160, 83, 300, 14);
        contentPane.add(lblStudentName);

        lblCourse = new JLabel("");
        lblCourse.setBounds(160, 117, 300, 14);
        contentPane.add(lblCourse);

        JLabel lblNewLabel_2 = new JLabel("Enter Student Id");
        lblNewLabel_2.setBounds(342, 83, 108, 14);
        contentPane.add(lblNewLabel_2);

        textField = new JTextField();
        textField.setBounds(474, 80, 130, 20);
        contentPane.add(textField);
        textField.setColumns(10);

        JButton btnNewButton = new JButton("View Report");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Fetch student ID from the text field
                int studentId = Integer.parseInt(textField.getText());

                // Fetch student data from the database
                fetchStudentData(studentId);
            }
        });
        btnNewButton.setBounds(471, 113, 133, 23);
        contentPane.add(btnNewButton);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(20, 191, 584, 200);
        contentPane.add(scrollPane);

        table_1 = new JTable();
        scrollPane.setViewportView(table_1);
        
        JButton btnGenerateReportSlip = new JButton("Generate Report Slip");
        btnGenerateReportSlip.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		navigate.navigateToResultSlipGenerator();
        	}
        });
        btnGenerateReportSlip.setBounds(474, 147, 133, 23);
        contentPane.add(btnGenerateReportSlip);
    }

    private void fetchStudentData(int studentId) {
        try (Connection connection = ConnectionHelper.createConnection()) {
            // Query to fetch student data
            String query = "SELECT p.name AS student_name, c.course_name AS course, m.module_name AS module, g.grade_value AS grade, g.percentage " +
                    "FROM finalAssemment.student s " +
                    "INNER JOIN finalAssemment.person p ON s.person_id = p.person_id " +
                    "INNER JOIN finalAssemment.course c ON s.course_id = c.course_id " +
                    "LEFT JOIN finalAssemment.modules m ON c.course_id = m.course_id " +
                    "LEFT JOIN finalAssemment.grade g ON s.student_id = g.student_id AND m.module_id = g.module_id " +
                    "WHERE s.student_id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, studentId);
            ResultSet resultSet = statement.executeQuery();

            // Check if the student exists
            if (resultSet.next()) {
                String studentName = resultSet.getString("student_name");
                String course = resultSet.getString("course");

                // Set student name and course labels
                lblStudentName.setText(studentName);
                lblCourse.setText(course);

                // Populate the table with fetched data
                DefaultTableModel model = new DefaultTableModel();
                model.addColumn("Student Name");
                model.addColumn("Course");
                model.addColumn("Module");
                model.addColumn("Grade");
                model.addColumn("Percentage");

                do {
                    String module = resultSet.getString("module");
                    String grade = resultSet.getString("grade");
                    double percentage = resultSet.getDouble("percentage");

                    model.addRow(new Object[]{studentName, course, module, grade, percentage});
                } while (resultSet.next());

                table_1.setModel(model);
            } else {
                JOptionPane.showMessageDialog(null, "Student with ID " + studentId + " does not exist.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                showStudentReport frame = new showStudentReport();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}
