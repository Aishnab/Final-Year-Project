package Assemment;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.Connection;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.awt.Font;

public class Teacher extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	  private JTable teacherTable;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Teacher frame = new Teacher();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Teacher() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 798, 479);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		   contentPane.setLayout(null);
		
		   teacherTable = new JTable();
	        JScrollPane scrollPane = new JScrollPane(teacherTable);
	        scrollPane.setBounds(93, 121, 612, 252);
	        contentPane.add(scrollPane);
	        
	        JButton btnNewButton = new JButton("Add Teacher");
	        btnNewButton.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
				navigate.navigateToAddTeacher();
				dispose();
					
				}
	        	
	        });
	     
	        btnNewButton.setBounds(93, 87, 117, 23);
	        contentPane.add(btnNewButton);
	        
	        JButton btnEditTeacher = new JButton("Edit Teacher");
	        btnEditTeacher.addActionListener(new ActionListener() {
	        	public void actionPerformed(ActionEvent e) {
	        		if ("Student".equals(UserInfo.getUserRole()) || "Teacher".equals(UserInfo.getUserRole())) {
			    	    Message.showErrorMessage("Only admin can use this feature");
			    	    return;
			    	}
	        		 editTeacher() ;
	        	}
	        });
	        btnEditTeacher.setBounds(241, 87, 117, 23);
	        contentPane.add(btnEditTeacher);
	        
	        JButton btnNewButton_1 = new JButton("Delete Teacher");
	        btnNewButton_1.addActionListener(new ActionListener() {
	        	public void actionPerformed(ActionEvent e) {
	        		if ("Student".equals(UserInfo.getUserRole()) || "Teacher".equals(UserInfo.getUserRole())) {
			    	    Message.showErrorMessage("Only admin can use this feature");
			    	    return;
			    	}
	        		deleteTeacher();
	        	}
	        });
	        btnNewButton_1.setBounds(385, 87, 123, 23);
	        contentPane.add(btnNewButton_1);
	        
	        JButton btnNewButton_2 = new JButton("Assign Module");
	        btnNewButton_2.addActionListener(new ActionListener() {
	        	public void actionPerformed(ActionEvent e) {
	        		if ("Student".equals(UserInfo.getUserRole()) || "Teacher".equals(UserInfo.getUserRole())) {
			    	    Message.showErrorMessage("Only admin can use this feature");
			    	    return;
			    	}
	    navigate.navigateToAssignModule();
	    dispose();
	        	}
	        });
	        btnNewButton.addActionListener(e -> {
	        	
	        });
	        btnNewButton_2.setBounds(541, 87, 117, 23);
	        contentPane.add(btnNewButton_2);
	        
	        JButton btnDashboard = new JButton("Dashboard");
	        btnDashboard.setBounds(124, 11, 117, 23);
	        contentPane.add(btnDashboard);
	        btnDashboard.addActionListener(new ActionListener() {
	        	public void actionPerformed(ActionEvent e) {
	        		navigate.navigateToDashboard();
	        		dispose();
	        	}
	        });
	        
	        JButton btnNewButton_3_1 = new JButton("Courses");
	        btnNewButton_3_1.addActionListener(new ActionListener() {
	        	public void actionPerformed(ActionEvent e) {
	        		navigate.navigateToCourse();
	        		dispose();
	        	}
	        });
	        btnNewButton_3_1.setBounds(276, 11, 117, 23);
	        contentPane.add(btnNewButton_3_1);
	        
	        JButton btnNewButton_3_1_1 = new JButton("Students");
	        btnNewButton_3_1_1.setBounds(424, 11, 117, 23);
	        contentPane.add(btnNewButton_3_1_1);
	        btnNewButton_3_1_1.addActionListener(new ActionListener() {
	        	public void actionPerformed(ActionEvent e) {
	        		navigate.navigateToStudents();
	        		dispose();
	        	}
	        });
	        
	        
	        JLabel lblNewLabel = new JLabel("Tutors");
	        lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
	        lblNewLabel.setBounds(10, 15, 60, 14);
	        contentPane.add(lblNewLabel);
	        

	        fetchTeacherData();
	}

	   private void fetchTeacherData() {
	        try (Connection connection = ConnectionHelper.createConnection()) {
	            DefaultTableModel model = new DefaultTableModel();
	            model.addColumn("Teacher ID");
	            model.addColumn("Teacher Name");
	            model.addColumn("Assigned Module");

	            // Fetch teacher data
	            String teacherQuery = "SELECT teacher_id, person_id FROM finalAssemment.teacher";
	            PreparedStatement teacherStatement = connection.prepareStatement(teacherQuery);
	            ResultSet teacherResultSet = teacherStatement.executeQuery();

	            while (teacherResultSet.next()) {
	                int teacherId = teacherResultSet.getInt("teacher_id");
	                int personId = teacherResultSet.getInt("person_id");
	                String teacherName = getTeacherName(connection, personId);
	                String assignedModule = getAssignedModule(connection, teacherId);
	                model.addRow(new Object[]{teacherId, teacherName, assignedModule});
	            }

	            teacherTable.setModel(model);
	        } catch (SQLException e) {
	            e.printStackTrace();
	            JOptionPane.showMessageDialog(this, "Error fetching teacher data", "Error", JOptionPane.ERROR_MESSAGE);
	        }
	    }

	    private String getTeacherName(Connection connection, int personId) throws SQLException {
	        String query = "SELECT name FROM finalAssemment.person WHERE person_id = ?";
	        PreparedStatement statement = connection.prepareStatement(query);
	        statement.setInt(1, personId);
	        ResultSet resultSet = statement.executeQuery();
	        return resultSet.next() ? resultSet.getString("name") : null;
	    }

	    private String getAssignedModule(Connection connection, int teacherId) throws SQLException {
	        String query = "SELECT module_name FROM finalAssemment.modules WHERE teacher_id = ?";
	        PreparedStatement statement = connection.prepareStatement(query);
	        statement.setInt(1, teacherId);
	        ResultSet resultSet = statement.executeQuery();
	        return resultSet.next() ? resultSet.getString("module_name") : null;
	    }
	    
	    private void editTeacher() {
	        String teacherIdInput = JOptionPane.showInputDialog("Enter the Teacher ID to edit:");
	        if (teacherIdInput == null || teacherIdInput.isEmpty()) {
	            JOptionPane.showMessageDialog(this, "Teacher ID is required. Please enter a Teacher ID.", "Error", JOptionPane.ERROR_MESSAGE);
	            return;
	        }

	        int teacherId;
	        try {
	            teacherId = Integer.parseInt(teacherIdInput);
	        } catch (NumberFormatException e) {
	            JOptionPane.showMessageDialog(this, "Invalid Teacher ID. Please enter a valid Teacher ID.", "Error", JOptionPane.ERROR_MESSAGE);
	            return;
	        }

	        if (!checkTeacherExists(teacherId)) {
	            JOptionPane.showMessageDialog(this, "No teacher exists with the provided ID.", "Error", JOptionPane.ERROR_MESSAGE);
	            return;
	        }

	        String newTeacherName = JOptionPane.showInputDialog("Enter the new teacher name:");
	        if (newTeacherName == null || newTeacherName.isEmpty()) {
	            JOptionPane.showMessageDialog(this, "New teacher name is required.", "Error", JOptionPane.ERROR_MESSAGE);
	            return;
	        }

	        try (Connection connection = ConnectionHelper.createConnection()) {
	            String updateQuery = "UPDATE finalAssemment.person SET name = ? WHERE person_id = (SELECT person_id FROM finalAssemment.teacher WHERE teacher_id = ?)";
	            PreparedStatement statement = connection.prepareStatement(updateQuery);
	            statement.setString(1, newTeacherName);
	            statement.setInt(2, teacherId);
	            int rowsAffected = statement.executeUpdate();

	            if (rowsAffected > 0) {
	                JOptionPane.showMessageDialog(this, "Teacher name updated successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
	                fetchTeacherData(); // Refresh the table
	            } else {
	                JOptionPane.showMessageDialog(this, "Failed to update teacher name.", "Error", JOptionPane.ERROR_MESSAGE);
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	            JOptionPane.showMessageDialog(this, "Error updating teacher name", "Error", JOptionPane.ERROR_MESSAGE);
	        }
	    }

	    private boolean checkTeacherExists(int teacherId) {
	        String selectTeacherSQL = "SELECT * FROM finalAssemment.teacher WHERE teacher_id = ?";
	        try (Connection connection = ConnectionHelper.createConnection();
	             PreparedStatement statement = connection.prepareStatement(selectTeacherSQL)) {
	            statement.setInt(1, teacherId);
	            ResultSet resultSet = statement.executeQuery();
	            return resultSet.next();
	        } catch (SQLException e) {
	            e.printStackTrace();
	            JOptionPane.showMessageDialog(this, "Error checking teacher existence", "Error", JOptionPane.ERROR_MESSAGE);
	            return false;
	        }
	    }
	    
	    private void deleteTeacher() {
	        String teacherIdInput = JOptionPane.showInputDialog("Enter the Teacher ID to delete:");
	        if (teacherIdInput == null || teacherIdInput.isEmpty()) {
	            JOptionPane.showMessageDialog(this, "Teacher ID is required. Please enter a Teacher ID.", "Error", JOptionPane.ERROR_MESSAGE);
	            return;
	        }

	        int teacherId;
	        try {
	            teacherId = Integer.parseInt(teacherIdInput);
	        } catch (NumberFormatException e) {
	            JOptionPane.showMessageDialog(this, "Invalid Teacher ID. Please enter a valid Teacher ID.", "Error", JOptionPane.ERROR_MESSAGE);
	            return;
	        }

	        if (!checkTeacherExists(teacherId)) {
	            JOptionPane.showMessageDialog(this, "No teacher exists with the provided ID.", "Error", JOptionPane.ERROR_MESSAGE);
	            return;
	        }

	        int confirmDelete = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this teacher?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
	        if (confirmDelete != JOptionPane.YES_OPTION) {
	            return;
	        }

	        try (Connection connection = ConnectionHelper.createConnection()) {
	            // Retrieve the person_id associated with the teacher_id
	            int personId = getPersonIdForTeacher(teacherId, connection);
	            if (personId == -1) {
	                JOptionPane.showMessageDialog(this, "Failed to retrieve person ID for the teacher.", "Error", JOptionPane.ERROR_MESSAGE);
	                return;
	            }

	            // Delete related records from the grade table
	            String deleteGradeQuery = "DELETE FROM finalAssemment.grade WHERE teacher_id = ?";
	            PreparedStatement gradeStatement = connection.prepareStatement(deleteGradeQuery);
	            gradeStatement.setInt(1, teacherId);
	            int gradeRowsAffected = gradeStatement.executeUpdate();

	            // Now delete the teacher record
	            String deleteTeacherQuery = "DELETE FROM finalAssemment.teacher WHERE teacher_id = ?";
	            PreparedStatement teacherStatement = connection.prepareStatement(deleteTeacherQuery);
	            teacherStatement.setInt(1, teacherId);
	            int teacherRowsAffected = teacherStatement.executeUpdate();

	            if (teacherRowsAffected > 0) {
	                // Now delete the corresponding person record
	                String deletePersonQuery = "DELETE FROM finalAssemment.person WHERE person_id = ?";
	                PreparedStatement personStatement = connection.prepareStatement(deletePersonQuery);
	                personStatement.setInt(1, personId);
	                int personRowsAffected = personStatement.executeUpdate();

	                if (personRowsAffected > 0) {
	                    JOptionPane.showMessageDialog(this, "Teacher deleted successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
	                    fetchTeacherData(); // Refresh the table
	                } else {
	                    JOptionPane.showMessageDialog(this, "Failed to delete teacher from person table.", "Error", JOptionPane.ERROR_MESSAGE);
	                }
	            } else {
	                JOptionPane.showMessageDialog(this, "Failed to delete teacher.", "Error", JOptionPane.ERROR_MESSAGE);
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	            JOptionPane.showMessageDialog(this, "Error deleting teacher.", "Error", JOptionPane.ERROR_MESSAGE);
	        }
	    }

	    private int getPersonIdForTeacher(int teacherId, Connection connection) throws SQLException {
	        // Retrieve the person_id associated with the given teacher_id from the teacher table
	        String query = "SELECT person_id FROM finalAssemment.teacher WHERE teacher_id = ?";
	        PreparedStatement statement = connection.prepareStatement(query);
	        statement.setInt(1, teacherId);
	        ResultSet resultSet = statement.executeQuery();

	        if (resultSet.next()) {
	            return resultSet.getInt("person_id");
	        } else {
	            return -1; // Indicates failure to retrieve person_id
	        }
	    }



}
