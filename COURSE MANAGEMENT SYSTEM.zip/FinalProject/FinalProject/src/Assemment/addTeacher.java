package Assemment;

import java.awt.EventQueue;
import java.sql.*;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class addTeacher extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					addTeacher frame = new addTeacher();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public addTeacher() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 742, 496);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Add Teacher");
		lblNewLabel.setBounds(31, 38, 112, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Name");
		lblNewLabel_1.setBounds(31, 89, 86, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Email");
		lblNewLabel_1_1.setBounds(31, 115, 86, 14);
		contentPane.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("Password");
		lblNewLabel_1_1_1.setBounds(31, 160, 86, 14);
		contentPane.add(lblNewLabel_1_1_1);
		
		JLabel lblNewLabel_1_1_1_1 = new JLabel("Confirm Password");
		lblNewLabel_1_1_1_1.setBounds(31, 188, 86, 14);
		contentPane.add(lblNewLabel_1_1_1_1);
		
		textField = new JTextField();
		textField.setBounds(177, 86, 276, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(177, 112, 276, 20);
		contentPane.add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(177, 157, 276, 20);
		contentPane.add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(177, 185, 276, 20);
		contentPane.add(textField_3);
		
		JButton btnNewButton = new JButton("Add Teacher");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				addTeacherToDatabase();
			}
		});
		btnNewButton.setBounds(177, 240, 118, 23);
		contentPane.add(btnNewButton);
	
 
     
		
		JButton btnCancel = new JButton("Cancel");
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				navigate.navigateToTeacher();
			}
		});
		btnCancel.setBounds(307, 240, 118, 23);
		contentPane.add(btnCancel);
	}
	
	private void addTeacherToDatabase() {
	    String name = textField.getText();
	    String email = textField_1.getText();
	    String password = textField_2.getText();
	    String confirmPassword = textField_3.getText();

	    if (name.isEmpty() || email.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
	    	Message.showErrorMessage( "All fields are required");
	        return;
	    }

	    if (!password.equals(confirmPassword)) {
	    	Message.showErrorMessage("Password and Confirm Password do not match");
	        return;
	    }
	    if (AuthenticationHelper.isEmailAlreadyRegistered(email)) {
            Message.showErrorMessage("User with this email already exists");
            return;
        }

	    try (Connection connection = ConnectionHelper.createConnection()) {
	        // Insert data into the person table
	        String insertPersonQuery = "INSERT INTO finalAssemment.person (name, email, password, role) VALUES (?, ?, ?, ?)";
	        PreparedStatement personStatement = connection.prepareStatement(insertPersonQuery, Statement.RETURN_GENERATED_KEYS);
	        personStatement.setString(1, name);
	        personStatement.setString(2, email);
	        personStatement.setString(3, password);
	        personStatement.setString(4, "Teacher");
	        personStatement.executeUpdate();

	        // Retrieve the generated person_id
	        ResultSet generatedKeys = personStatement.getGeneratedKeys();
	        int personId = -1;
	        if (generatedKeys.next()) {
	            personId = generatedKeys.getInt(1);
	        } else {
	            throw new SQLException("Failed to get person ID, no rows affected.");
	        }

	        // Insert data into the teacher table
	        String insertTeacherQuery = "INSERT INTO finalAssemment.teacher (person_id, role) VALUES (?, ?)";
	        PreparedStatement teacherStatement = connection.prepareStatement(insertTeacherQuery);
	        teacherStatement.setInt(1, personId);
	        teacherStatement.setString(2, "Teacher");
	        teacherStatement.executeUpdate();
      Message.showSuccessMessage("Success");
      navigate.navigateToTeacher();
	      
	    } catch (SQLException ex) {
	        ex.printStackTrace();
	        Message.showErrorMessage( "Error adding teacher");
	    }
	}

}
