package Assemment;
import java.awt.EventQueue;


import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemListener;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.DefaultComboBoxModel;
import java.sql.*;

public class Register extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField textField;
    private JTextField textField_1;
    private JTextField textField_2;
    private JTextField textField_3;
    private JComboBox<String> comboBox;
    private JComboBox<String> comboBox_1 ;
    
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Register frame = new Register();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public Register() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 923, 498);
        contentPane = new JPanel();
        contentPane.setBackground(Color.WHITE);
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel name = new JLabel("Name");
        name.setBounds(274, 74, 64, 14);
        contentPane.add(name);

        JLabel email = new JLabel("Email");
        email.setBounds(274, 99, 64, 14);
        contentPane.add(email);

        JLabel password = new JLabel("Password");
        password.setBounds(274, 124, 64, 14);
        contentPane.add(password);

        textField = new JTextField();
        textField.setBounds(401, 71, 188, 20);
        contentPane.add(textField);
        textField.setColumns(10);

        textField_1 = new JTextField();
        textField_1.setColumns(10);
        textField_1.setBounds(401, 96, 188, 20);
        contentPane.add(textField_1);

        textField_2 = new JTextField();
        textField_2.setColumns(10);
        textField_2.setBounds(401, 121, 188, 20);
        contentPane.add(textField_2);

        JButton btnNewButton = new JButton("Register");
     
   
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
         
                String userName = textField.getText();
                String email = textField_1.getText();
                String password = textField_2.getText();
                String confirmPassword = textField_3.getText();
                String selectedRole = (String) comboBox.getSelectedItem();
              

                if (AuthenticationHelper.validateInput(userName, email, password, confirmPassword)) {
                	try {
                	    if ( AuthenticationHelper.isEmailAlreadyRegistered(email) ) {
                	        Message.showErrorMessage("User with this email already exists");
                	    }              	    
                	    else {
                	        
                	        Connection conn = ConnectionHelper.createConnection();
                	                    	      
                	        String insertPersonQuery = "INSERT INTO finalAssemment.person (name, email, password, role) VALUES (?, ?, ?, ?)";
                	        try (PreparedStatement pstmt = conn.prepareStatement(insertPersonQuery, Statement.RETURN_GENERATED_KEYS)) {
                	            pstmt.setString(1, userName);
                	            pstmt.setString(2, email);
                	            pstmt.setString(3, password);
                	            pstmt.setString(4, selectedRole);
                	            pstmt.executeUpdate();

                	            // Retrieve the person_id for the newly inserted user
                	            ResultSet generatedKeys = pstmt.getGeneratedKeys();
                	            int personId = -1;
                	            if (generatedKeys.next()) {
                	                personId = generatedKeys.getInt(1);
                	            }
          
                	            if ("Admin".equals(selectedRole)) {
                	                String insertAdminQuery = "INSERT INTO finalAssemment.admin (person_id) VALUES (?)";
                	                try (PreparedStatement adminStmt = conn.prepareStatement(insertAdminQuery)) {
                	                    adminStmt.setInt(1, personId);
                	                    adminStmt.executeUpdate();
                	                }
                	            } else if ("Teacher".equals(selectedRole)) {
                	                String insertTeacherQuery = "INSERT INTO finalAssemment.teacher (person_id) VALUES (?)";
                	                try (PreparedStatement teacherStmt = conn.prepareStatement(insertTeacherQuery)) {
                	                    teacherStmt.setInt(1, personId);
                	                    teacherStmt.executeUpdate();
                	                }
                	            } else if ("Student".equals(selectedRole)) {              	         
                	                String selectedCourse = (String) comboBox_1.getSelectedItem();
                	                int courseId = AuthenticationHelper.getCourseIdForSelectedCourse(selectedCourse);

                	                String insertStudentQuery = "INSERT INTO finalAssemment.student (person_id, course_id) VALUES (?, ?)";
                	                try (PreparedStatement studentStmt = conn.prepareStatement(insertStudentQuery)) {
                	                    studentStmt.setInt(1, personId);
                	                    studentStmt.setInt(2, courseId);
                	                    studentStmt.executeUpdate();
                	                }
                	            }

                	            JOptionPane.showMessageDialog(null, "Registration Successful", "Success", JOptionPane.INFORMATION_MESSAGE);
                	            navigate.navigateToLogin();
                	            dispose();
                	        }

                	        conn.close();
                	    }
                	} catch (Exception ee) {
                	    System.err.println("Got an exception!");
                	    System.err.println(ee.getMessage());
                	}

                }
            }
        });

        
        btnNewButton.setBounds(411, 241, 84, 23);
        contentPane.add(btnNewButton);

        JLabel lblNewLabel_1 = new JLabel("Register Page");
        lblNewLabel_1.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        lblNewLabel_1.setBounds(274, 21, 165, 20);
        contentPane.add(lblNewLabel_1);

        JButton btnLogin = new JButton("Login");
        btnLogin.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                navigate.navigateToLogin();
                dispose();
            }
        });
        btnLogin.setBounds(505, 241, 84, 23);
        contentPane.add(btnLogin);

        JLabel confirmPasswordLabel = new JLabel("Confirm Password");
        confirmPasswordLabel.setBounds(274, 149, 152, 14);
        contentPane.add(confirmPasswordLabel);

        textField_3 = new JTextField();
        textField_3.setColumns(10);
        textField_3.setBounds(401, 146, 188, 20);
        contentPane.add(textField_3);

        comboBox = new JComboBox<String>();
        comboBox.setModel(new DefaultComboBoxModel<String>(new String[] { "Student", "Admin", "Teacher" }));
        comboBox.setBounds(401, 174, 188, 22);
        contentPane.add(comboBox);
           

        JSeparator separator = new JSeparator();
        separator.setBounds(49, 170, 1, 2);
        contentPane.add(separator);

        JLabel role = new JLabel("Role");
        role.setBounds(274, 178, 46, 14);
        contentPane.add(role);
        
        comboBox_1 = new JComboBox<String>();
        comboBox_1.setBounds(401, 207, 188, 22);
        contentPane.add(comboBox_1);
        fetchCourseAndPutInComboBox(); //function to fetch all course from the database
           
   
        comboBox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String selectedRole = (String) comboBox.getSelectedItem();
                System.out.println(selectedRole);

                if ("Student".equals(selectedRole)) {              
                    comboBox_1.removeAllItems(); 
                    fetchCourseAndPutInComboBox(); 
                    comboBox_1.setVisible(true);
                } else {
                    comboBox_1.setVisible(false);
                    comboBox_1.setSelectedItem(null);
                }
            }
        });
  
      
    }
    
    private void fetchCourseAndPutInComboBox() {
    	
    	    try (Connection conn = ConnectionHelper.createConnection();
    	         Statement stmt = conn.createStatement();
    	         ResultSet rs = stmt.executeQuery("SELECT course_name FROM finalAssemment.course")) {

    	        while (rs.next()) {
    	            comboBox_1.addItem(rs.getString("course_name"));
    	        }

    	    } catch (SQLException ex) {
    	        ex.printStackTrace();
    	    }
    }
  
}
