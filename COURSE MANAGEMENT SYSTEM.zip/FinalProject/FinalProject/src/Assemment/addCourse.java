package Assemment;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JEditorPane;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.sql.*;

public class addCourse extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					addCourse frame = new addCourse();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public addCourse() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 784, 492);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Add Course");
		lblNewLabel.setBounds(59, 11, 152, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblModule = new JLabel("Module 1");
		lblModule.setBounds(59, 83, 140, 14);
		contentPane.add(lblModule);
		
		JLabel lblNewLabel_1_1 = new JLabel("Module 2");
		lblNewLabel_1_1.setBounds(59, 123, 172, 14);
		contentPane.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("Module 3\r\n");
		lblNewLabel_1_1_1.setBounds(59, 165, 134, 14);
		contentPane.add(lblNewLabel_1_1_1);
		
		JLabel lblNewLabel_1_1_1_1 = new JLabel("Module 4\r\n");
		lblNewLabel_1_1_1_1.setBounds(59, 209, 152, 14);
		contentPane.add(lblNewLabel_1_1_1_1);
		
		JLabel lblNewLabel_1_1_1_1_1 = new JLabel("Course Name");
		lblNewLabel_1_1_1_1_1.setBounds(59, 44, 116, 14);
		contentPane.add(lblNewLabel_1_1_1_1_1);
		
		JButton btnNewButton = new JButton("Add Course");
		 btnNewButton.addActionListener(new ActionListener() {
		        public void actionPerformed(ActionEvent e) {
		            submitCourse();
		        }
		    });
		  
		btnNewButton.setBounds(203, 263, 226, 23);
		contentPane.add(btnNewButton);
		
		
		
		textField = new JTextField();
		textField.setBounds(203, 41, 226, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(203, 80, 226, 20);
		contentPane.add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(203, 120, 226, 20);
		contentPane.add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(203, 162, 226, 20);
		contentPane.add(textField_3);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(203, 206, 226, 20);
		contentPane.add(textField_4);
		
		JButton btnCancel = new JButton("Cancel");
		btnCancel.setBounds(203, 300, 226, 23);
		contentPane.add(btnCancel);
		 btnCancel.addActionListener(new ActionListener() {
		        public void actionPerformed(ActionEvent e) {
		           Course course = new Course();
		           course.setVisible(true);
		           dispose();
		        }
		    });
	}
	
	private void submitCourse() {
	
	    String courseName = textField.getText().trim();

	   
	    if (courseName.isEmpty()) { 
	      Message.showErrorMessage("Course Name is required");
	        return;
	    }


	    String moduleName1 = textField_1.getText().trim();
	    String moduleName2 = textField_2.getText().trim();
	    String moduleName3 = textField_3.getText().trim();
	    String moduleName4 = textField_4.getText().trim();

	
	    if (moduleName1.isEmpty() && moduleName2.isEmpty() && moduleName3.isEmpty() && moduleName4.isEmpty()) {
	     
	        JOptionPane.showMessageDialog(this, "At least one module is required", "Error", JOptionPane.ERROR_MESSAGE);
	        return;
	    }

	    if (addCourseToDatabase(courseName, moduleName1, moduleName2, moduleName3, moduleName4)) {
       
            JOptionPane.showMessageDialog(this, "Course added successfully", "Success", JOptionPane.INFORMATION_MESSAGE);
            Course course = new Course();
            course.setVisible(true);
            dispose();
        } else {
      
            JOptionPane.showMessageDialog(this, "Failed to add course", "Error", JOptionPane.ERROR_MESSAGE);
        }

	
	}
	
	private boolean addCourseToDatabase(String courseName, String moduleName1, String moduleName2, String moduleName3, String moduleName4) {
	    // SQL statements to insert course and modules
	    String insertCourseSQL = "INSERT INTO course (course_name) VALUES (?)";
	    String insertModuleSQL = "INSERT INTO modules (module_name, course_id) VALUES (?, ?)";

	    try (Connection connection = ConnectionHelper.createConnection();
	         PreparedStatement courseStatement = connection.prepareStatement(insertCourseSQL, Statement.RETURN_GENERATED_KEYS);
	         PreparedStatement moduleStatement = connection.prepareStatement(insertModuleSQL)) {

	        // Insert course
	        courseStatement.setString(1, courseName);
	        int affectedRows = courseStatement.executeUpdate();
	        if (affectedRows == 0) {
	            return false;
	        }

	        // Get the generated course ID
	        try (ResultSet generatedKeys = courseStatement.getGeneratedKeys()) {
	            if (generatedKeys.next()) {
	                int courseId = generatedKeys.getInt(1);

	                // Insert modules
	                insertModule(moduleStatement, courseId, moduleName1);
	                insertModule(moduleStatement, courseId, moduleName2);
	                insertModule(moduleStatement, courseId, moduleName3);
	                insertModule(moduleStatement, courseId, moduleName4);

	                // Execute batch insert
	                moduleStatement.executeBatch();
	                return true;
	            } else {
	                return false;
	            }
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	        return false;
	    }
	}

	private void insertModule(PreparedStatement moduleStatement, int courseId, String moduleName) throws SQLException {
	    if (!moduleName.isEmpty()) {
	        moduleStatement.setString(1, moduleName);
	        moduleStatement.setInt(2, courseId);
	        moduleStatement.addBatch();
	    }
	}


}
