package Assemment;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.sql.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class resultSlipGenerator extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JComboBox<String> studentComboBox;
    private JComboBox<String> moduleComboBox;
    private JComboBox<String> gradeComboBox;
    private JComboBox<String> progressComboBox;
    private JTextField textField;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    resultSlipGenerator frame = new resultSlipGenerator();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public resultSlipGenerator() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 450, 300);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblNewLabel = new JLabel("Select Student:");
        lblNewLabel.setBounds(20, 30, 100, 14);
        contentPane.add(lblNewLabel);

        studentComboBox = new JComboBox<>();
        studentComboBox.setBounds(130, 27, 200, 20);
        contentPane.add(studentComboBox);

        JLabel lblNewLabel_1 = new JLabel("Select Module:");
        lblNewLabel_1.setBounds(20, 70, 100, 14);
        contentPane.add(lblNewLabel_1);

        moduleComboBox = new JComboBox<>();
        moduleComboBox.setBounds(130, 67, 200, 20);
        contentPane.add(moduleComboBox);

     

        JLabel lblProgress = new JLabel("Progress:");
        lblProgress.setBounds(20, 150, 100, 14);
        contentPane.add(lblProgress);

        progressComboBox = new JComboBox<>();
        progressComboBox.addItem("Yes");
        progressComboBox.addItem("No");
        progressComboBox.setBounds(130, 147, 50, 20);
        contentPane.add(progressComboBox);

        JButton btnGenerateReport = new JButton("Generate Report");
        btnGenerateReport.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                generateReport();
            }
        });
        btnGenerateReport.setBounds(130, 180, 150, 23);
        contentPane.add(btnGenerateReport);
        
        JLabel lblNewLabel_1_1 = new JLabel("Percentage");
        lblNewLabel_1_1.setBounds(20, 109, 100, 14);
        contentPane.add(lblNewLabel_1_1);
        
        textField = new JTextField();
        textField.setBounds(130, 106, 200, 20);
        contentPane.add(textField);
        textField.setColumns(10);

        studentComboBox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String selectedStudent = (String) studentComboBox.getSelectedItem();
                int studentId = Integer.parseInt(selectedStudent.split(" - ")[0]);
                int courseId = fetchCourseIdForStudent(studentId);
                populateModuleComboBox(courseId);
            }
        });

        populateStudentComboBox();
    }

    private void populateStudentComboBox() {
        try (Connection connection = ConnectionHelper.createConnection()) {
            String studentQuery = "SELECT student_id, person_id FROM finalAssemment.student";
            PreparedStatement studentStatement = connection.prepareStatement(studentQuery);
            ResultSet studentResultSet = studentStatement.executeQuery();

            while (studentResultSet.next()) {
                int studentId = studentResultSet.getInt("student_id");
                int personId = studentResultSet.getInt("person_id");
                String studentName = getStudentName(connection, personId);
                studentComboBox.addItem(studentId + " - " + studentName);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error fetching student data", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private String getStudentName(Connection connection, int personId) throws SQLException {
        String query = "SELECT name FROM finalAssemment.person WHERE person_id = ?";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setInt(1, personId);
        ResultSet resultSet = statement.executeQuery();
        return resultSet.next() ? resultSet.getString("name") : null;
    }

    private void generateReport() {
        String selectedStudent = (String) studentComboBox.getSelectedItem();
        String selectedModule = (String) moduleComboBox.getSelectedItem();
        String selectedProgress = (String) progressComboBox.getSelectedItem();
        double percentage = Double.parseDouble(textField.getText());

        int studentId = Integer.parseInt(selectedStudent.split(" - ")[0]);
        int courseId = fetchCourseIdForStudent(studentId);
        int moduleId = Integer.parseInt(selectedModule.split(" - ")[0]);
        String grade = calculateGrade(percentage);

        try (Connection connection = ConnectionHelper.createConnection()) {
            String insertQuery = "INSERT INTO finalAssemment.report (sender_id, receiver_id, moduleId, grade, progress, percentage) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(insertQuery, Statement.RETURN_GENERATED_KEYS);
            statement.setInt(1, 1);
            statement.setInt(2, studentId); // Receiver is the student
            statement.setInt(3, moduleId);
            statement.setString(4, grade);
            statement.setString(5, selectedProgress);
            statement.setDouble(6, percentage);
            statement.executeUpdate();

            ResultSet generatedKeys = statement.getGeneratedKeys();
            if (generatedKeys.next()) {
                int reportId = generatedKeys.getInt(1);
                JOptionPane.showMessageDialog(null, "Report generated successfully with ID: " , "Success", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error generating report", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void populateModuleComboBox(int courseId) {
        moduleComboBox.removeAllItems();
        try (Connection connection = ConnectionHelper.createConnection()) {
            String moduleQuery = "SELECT module_id, module_name FROM finalAssemment.modules WHERE course_id = ?";
            PreparedStatement moduleStatement = connection.prepareStatement(moduleQuery);
            moduleStatement.setInt(1, courseId);
            ResultSet moduleResultSet = moduleStatement.executeQuery();

            while (moduleResultSet.next()) {
                int moduleId = moduleResultSet.getInt("module_id");
                String moduleName = moduleResultSet.getString("module_name");
                moduleComboBox.addItem(moduleId + " - " + moduleName);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error fetching module data", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private int fetchCourseIdForStudent(int studentId) {
        int courseId = -1;
        try (Connection connection = ConnectionHelper.createConnection()) {
            String courseIdQuery = "SELECT course_id FROM finalAssemment.student WHERE student_id = ?";
            PreparedStatement statement = connection.prepareStatement(courseIdQuery);
            statement.setInt(1, studentId);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                courseId = resultSet.getInt("course_id");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error fetching course ID for student", "Error", JOptionPane.ERROR_MESSAGE);
        }
        return courseId;
    }
    
    private String calculateGrade(double percentage) {
        // Implement logic to calculate grade from percentage
        // This is just a placeholder method, replace it with your actual logic
        if (percentage >= 90) {
            return "A+";
        } else if (percentage >= 80) {
            return "A";
        } else if (percentage >= 70) {
            return "B+";
        } else if (percentage >= 60) {
            return "B";
        } else if (percentage >= 50) {
            return "C+";
        } else if (percentage >= 40) {
            return "C";
        } else if (percentage >= 30) {
            return "D+";
        } else if (percentage >= 20) {
            return "D";
        } else {
            return "E";
        }
    }
}
