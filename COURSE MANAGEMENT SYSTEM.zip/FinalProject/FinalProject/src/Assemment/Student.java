package Assemment;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JButton;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import java.sql.*;
import java.awt.Font;
public class Student extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Student frame = new Student();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Student() {
		if(UserInfo.getUserName()== null) {
			dispose();
			navigate.navigateToLogin();
			return;
		}
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 866, 498);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Student");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel.setBounds(27, 28, 120, 14);
		contentPane.add(lblNewLabel);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(47, 191, 749, 124);
		contentPane.add(scrollPane);
		
		table = new JTable(fetch.getStudentDataModel() );
		scrollPane.setViewportView(table);
	
		JButton btnNewButton = new JButton("Add Student");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				navigate.navigateToAddStudent();
				dispose();
			}
		});
		btnNewButton.setBounds(47, 157, 131, 23);
		contentPane.add(btnNewButton);
		
		JButton btnEditStudent = new JButton("Edit Student");
		   btnEditStudent.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
	            	if ("Student".equals(UserInfo.getUserRole()) || "Teacher".equals(UserInfo.getUserRole())) {
			    	    Message.showErrorMessage("Only admin can use this feature");
			    	    return;
			    	}
	            edit();
	            }
	        });
		btnEditStudent.setBounds(205, 157, 131, 23);
		contentPane.add(btnEditStudent);
		
		JButton btnNewButton_1_1 = new JButton("Delete Student");
		btnNewButton_1_1.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		    	 try {
					deleteStudent();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
		    	
		    }
		});

		btnNewButton_1_1.setBounds(365, 157, 131, 23);
		contentPane.add(btnNewButton_1_1);
		
		JButton btnNewButton_1 = new JButton("Courses");
		btnNewButton_1.setBounds(179, 26, 89, 23);
		contentPane.add(btnNewButton_1);
		   btnNewButton_1.addActionListener(new ActionListener() {
	        	public void actionPerformed(ActionEvent e) {
	        		navigate.navigateToCourse();
	        		dispose();
	        	}
	        });
		JButton btnNewButton_2 = new JButton("Dashboard");
		btnNewButton_2.setBounds(309, 26, 149, 23);
		contentPane.add(btnNewButton_2);
		   btnNewButton_2.addActionListener(new ActionListener() {
	        	public void actionPerformed(ActionEvent e) {
	        		navigate.navigateToDashboard();
	        		dispose();
	        	}
	        });
		
		JButton btnNewButton_3 = new JButton("Tutors");
		btnNewButton_3.setBounds(485, 26, 89, 23);
		contentPane.add(btnNewButton_3);
		
		JButton btnNewButton_1_1_1 = new JButton("Grade Student");
		btnNewButton_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if ("Student".equals(UserInfo.getUserRole()) || "Admin".equals(UserInfo.getUserRole())) {
		    	    Message.showErrorMessage("Only teacher can use this feature");
		    	    return;
		    	}
				navigate.navigateToGradeStudent();
				dispose();
			}
		});
		btnNewButton_1_1_1.setBounds(537, 157, 131, 23);
		contentPane.add(btnNewButton_1_1_1);
		
		JButton btnNewButton_1_1_1_1 = new JButton("View Progreess");
		btnNewButton_1_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				navigate.navigateToStudentReport();
			}
		});
		btnNewButton_1_1_1_1.setBounds(688, 157, 131, 23);
		contentPane.add(btnNewButton_1_1_1_1);
		   btnNewButton_3.addActionListener(new ActionListener() {
	        	public void actionPerformed(ActionEvent e) {
	        		navigate.navigateToTeacher();
	        		dispose();
	        	}
	        });
	}
	

	private void deleteStudent() throws SQLException {
	    // Prompt the user to enter the Student ID to delete
	    String studentIdInput = JOptionPane.showInputDialog("Enter the Student ID to delete:");
	    if (studentIdInput == null || studentIdInput.isEmpty()) {
	        Message.showErrorMessage("Student ID is required. Please enter a Student ID.");
	        return;
	    }

	    // Parse the input to an integer
	    int studentId;
	    try {
	        studentId = Integer.parseInt(studentIdInput);
	    } catch (NumberFormatException e) {
	        Message.showErrorMessage("Invalid Student ID. Please enter a valid Student ID.");
	        return;
	    }

	    // Check if the student exists
	    if (!checkStudentExists(studentId)) {
	        Message.showErrorMessage("No student exists with the provided ID.");
	        return;
	    }

	    // Confirm deletion with the user
	    int confirmDelete = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this student?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
	    if (confirmDelete != JOptionPane.YES_OPTION) {
	        return;
	    }

	    try (Connection connection = ConnectionHelper.createConnection()) {
	        // Retrieve the person_id associated with the student_id
	        int personId = getPersonId(studentId, connection);
	        if (personId == -1) {
	            Message.showErrorMessage("Failed to retrieve person ID for the student");
	            return;
	        }

	        // Prepare the delete query for student table
	        String deleteStudentQuery = "DELETE FROM finalAssemment.student WHERE student_id = ?";
	        PreparedStatement deleteStudentStatement = connection.prepareStatement(deleteStudentQuery);
	        deleteStudentStatement.setInt(1, studentId);

	        // Execute the delete query for student table
	        int studentRowsAffected = deleteStudentStatement.executeUpdate();

	        // Prepare the delete query for person table
	        String deletePersonQuery = "DELETE FROM finalAssemment.person WHERE person_id = ?";
	        PreparedStatement deletePersonStatement = connection.prepareStatement(deletePersonQuery);
	        deletePersonStatement.setInt(1, personId);

	        // Execute the delete query for person table
	        int personRowsAffected = deletePersonStatement.executeUpdate();

	        // Check if deletion was successful in both tables
	        if (studentRowsAffected > 0 && personRowsAffected > 0) {
	            Message.showSuccessMessage("Student deleted successfully");

	            // Refresh the table model after deletion
	            DefaultTableModel model = fetch.getStudentDataModel();
	            table.setModel(model);
	        } else {
	            Message.showErrorMessage("Failed to delete student and corresponding person");
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	        Message.showErrorMessage("Error deleting student and corresponding person");
	    }
	}


	

private int getPersonId(int studentId, Connection connection) throws SQLException {
    // Retrieve the person_id associated with the given student_id from the student table
    String query = "SELECT person_id FROM finalAssemment.student WHERE student_id = ?";
    PreparedStatement statement = connection.prepareStatement(query);
    statement.setInt(1, studentId);
    ResultSet resultSet = statement.executeQuery();

    if (resultSet.next()) {
        return resultSet.getInt("person_id");
    } else {
        return -1; // Indicates failure to retrieve person_id
    }}




	public  void edit() {
	    try {
	        String studentIdInput = JOptionPane.showInputDialog("Enter the Student ID to edit:");
	        if (studentIdInput == null || studentIdInput.isEmpty()) {
	            throw new IllegalArgumentException("Student ID is required. Please enter a Student ID.");
	        }
	        
	        int studentId = Integer.parseInt(studentIdInput);
	        
	        if (!checkStudentExists(studentId)) {
	            throw new IllegalArgumentException("No student exists with the provided ID");
	        }
	        
	        String newStudentName = JOptionPane.showInputDialog("Enter the new student name:");
	        if (newStudentName == null || newStudentName.isEmpty()) {
	            throw new IllegalArgumentException("New student name is required");
	        }
	        
	        boolean success = updateStudentName(studentId, newStudentName);
	        if (success) {
	            JOptionPane.showMessageDialog(null, "Student name updated successfully", "Success", JOptionPane.INFORMATION_MESSAGE);
	            DefaultTableModel model = fetch.getStudentDataModel();
	            table.setModel(model);
	        } else {
	            throw new SQLException("Error updating student name");
	        }
	    } catch ( SQLException ex) {
	        JOptionPane.showMessageDialog(null, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
	    }
	}
	
	private boolean updateStudentName(int studentId, String newStudentName) throws SQLException {
	    String updateStudentNameSQL = "UPDATE finalAssemment.person SET name = ? WHERE person_id = (SELECT person_id FROM finalAssemment.student WHERE student_id = ?)";
	    try (Connection connection = ConnectionHelper.createConnection();
	         PreparedStatement statement = connection.prepareStatement(updateStudentNameSQL)) {
	        statement.setString(1, newStudentName);
	        statement.setInt(2, studentId);
	        int rowsAffected = statement.executeUpdate();
	        
	        return rowsAffected > 0;
	  
}}
	
	private boolean checkStudentExists(int studentId) throws SQLException {
	    String selectStudentSQL = "SELECT * FROM finalAssemment.student WHERE student_id = ?";
	    try (Connection connection = ConnectionHelper.createConnection();
	         PreparedStatement statement = connection.prepareStatement(selectStudentSQL)) {
	        statement.setInt(1, studentId);
	        ResultSet resultSet = statement.executeQuery();
	        return resultSet.next();
	    }
	}
	

	
}
