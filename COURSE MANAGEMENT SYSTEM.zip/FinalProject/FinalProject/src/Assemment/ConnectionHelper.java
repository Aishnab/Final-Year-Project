package Assemment;

import java.sql.*;

public class ConnectionHelper {
	 public static Connection createConnection() throws SQLException {
	        String url = "jdbc:mysql://localhost:3306/finalAssemment";
	        String username = "root";
	        String password = "";
	        return DriverManager.getConnection(url, username, password);
	    }
}
