package Assemment;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class assignModule extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JComboBox<String> comboBoxTeacher;
    private JComboBox<String> comboBoxCourse;
    private JComboBox<String> comboBoxModule;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    assignModule frame = new assignModule();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public assignModule() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 528, 378);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblNewLabel = new JLabel("Assign Module");
        lblNewLabel.setBounds(33, 31, 76, 14);
        contentPane.add(lblNewLabel);

        JLabel lblNewLabel_1 = new JLabel("Teachers");
        lblNewLabel_1.setBounds(33, 73, 64, 14);
        contentPane.add(lblNewLabel_1);

        comboBoxTeacher = new JComboBox();
        comboBoxTeacher.setBounds(157, 69, 214, 22);
        contentPane.add(comboBoxTeacher);

        JLabel lblNewLabel_1_1 = new JLabel("Courses");
        lblNewLabel_1_1.setBounds(33, 106, 64, 14);
        contentPane.add(lblNewLabel_1_1);

        comboBoxCourse = new JComboBox();
        comboBoxCourse.setBounds(157, 102, 214, 22);
        contentPane.add(comboBoxCourse);
        comboBoxCourse.addItemListener(new ItemListener() {
            public void itemStateChanged(ItemEvent e) {
                if (e.getStateChange() == ItemEvent.SELECTED) {
                    fetchModulesForCourse();
                }
            }
        });

        JLabel lblNewLabel_1_2 = new JLabel("Modules");
        lblNewLabel_1_2.setBounds(33, 130, 64, 14);
        contentPane.add(lblNewLabel_1_2);

        comboBoxModule = new JComboBox();
        comboBoxModule.setBounds(157, 126, 214, 22);
        contentPane.add(comboBoxModule);

        JButton btnNewButton = new JButton("Assign");
        btnNewButton.setBounds(157, 194, 89, 23);
        contentPane.add(btnNewButton);
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                assignModuleToTeacher();
                navigate.navigateToTeacher();
                dispose();
            }
        });

        JButton btnCancel = new JButton("Cancel");
        btnCancel.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		navigate.navigateToTeacher();
        	}
        });
        btnCancel.setBounds(282, 194, 89, 23);
        contentPane.add(btnCancel);

        fetchTeachersAndCourses();
    }

    private void fetchTeachersAndCourses() {
        try (Connection connection = ConnectionHelper.createConnection()) {
            // Fetch teachers
            String teacherQuery = "SELECT teacher_id, person_id FROM finalAssemment.teacher";
            PreparedStatement teacherStatement = connection.prepareStatement(teacherQuery);
            ResultSet teacherResultSet = teacherStatement.executeQuery();

            while (teacherResultSet.next()) {
                int teacherId = teacherResultSet.getInt("teacher_id");
                int personId = teacherResultSet.getInt("person_id");
                String teacherName = getTeacherName(connection, personId);
                comboBoxTeacher.addItem(teacherId + " - " + teacherName);
            }

            // Fetch courses
            String courseQuery = "SELECT course_id, course_name FROM finalAssemment.course";
            PreparedStatement courseStatement = connection.prepareStatement(courseQuery);
            ResultSet courseResultSet = courseStatement.executeQuery();

            while (courseResultSet.next()) {
                int courseId = courseResultSet.getInt("course_id");
                String courseName = courseResultSet.getString("course_name");
                comboBoxCourse.addItem(courseId + " - " + courseName);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error fetching data", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private String getTeacherName(Connection connection, int personId) throws SQLException {
        String query = "SELECT name FROM finalAssemment.person WHERE person_id = ?";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setInt(1, personId);
        ResultSet resultSet = statement.executeQuery();
        return resultSet.next() ? resultSet.getString("name") : null;
    }

    private void fetchModulesForCourse() {
        comboBoxModule.removeAllItems(); // Clear existing modules
        String selectedCourse = (String) comboBoxCourse.getSelectedItem();
        int courseId = Integer.parseInt(selectedCourse.split(" - ")[0]);
        try (Connection connection = ConnectionHelper.createConnection()) {
            // Fetch modules for the selected course
            String moduleQuery = "SELECT module_id, module_name FROM finalAssemment.modules WHERE course_id = ?";
            PreparedStatement moduleStatement = connection.prepareStatement(moduleQuery);
            moduleStatement.setInt(1, courseId);
            ResultSet moduleResultSet = moduleStatement.executeQuery();

            while (moduleResultSet.next()) {
                int moduleId = moduleResultSet.getInt("module_id");
                String moduleName = moduleResultSet.getString("module_name");
                comboBoxModule.addItem(moduleId + " - " + moduleName);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error fetching data", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void assignModuleToTeacher() {
        String selectedTeacher = (String) comboBoxTeacher.getSelectedItem();
        String selectedModule = (String) comboBoxModule.getSelectedItem();

        // Extract teacher ID and module ID from the selected strings
        int teacherId = Integer.parseInt(selectedTeacher.split(" - ")[0]);
        int moduleId = Integer.parseInt(selectedModule.split(" - ")[0]);

        try (Connection connection = ConnectionHelper.createConnection()) {
            String insertQuery = "UPDATE finalAssemment.modules SET teacher_id = ? WHERE module_id = ?";
            PreparedStatement statement = connection.prepareStatement(insertQuery);
            statement.setInt(1, teacherId);
            statement.setInt(2, moduleId);
            int rowsAffected = statement.executeUpdate();

            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(null, "Module assigned successfully", "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Failed to assign module", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error assigning module", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
