package Assemment;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import java.sql.*;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
public class Course extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Course frame = new Course();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Course() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 778, 482);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(79, 149, 589, 162);
		contentPane.add(scrollPane);
		
		table = new JTable(getCourseData());
		scrollPane.setViewportView(table);
		
		JButton btnNewButton = new JButton("Add Course");
		btnNewButton.setBounds(79, 115, 121, 23);
		contentPane.add(btnNewButton);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if ("Student".equals(UserInfo.getUserRole()) || "Teacher".equals(UserInfo.getUserRole())) {
		    	    Message.showErrorMessage("Only admin can use this feature");
		    	    return;
		    	}
				addCourse openAddCourse = new addCourse();
				openAddCourse.setVisible(true);
				dispose();
			}
		});
	
		
		JButton btnNewButton_1 = new JButton("Edit Course");
		btnNewButton_1.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		    	if ("Student".equals(UserInfo.getUserRole()) || "Teacher".equals(UserInfo.getUserRole())) {
		    	    Message.showErrorMessage("Only admin can use this feature");
		    	    return;
		    	}
		        // Prompt the user to enter the course ID and the updated course name
		        String courseIdInput = JOptionPane.showInputDialog("Enter the Course ID to edit:");
		        String newCourseName = JOptionPane.showInputDialog("Enter the updated course name:");

		        if (!AuthenticationHelper.isEmpty(courseIdInput)  && !AuthenticationHelper.isEmpty(newCourseName)) {
		            try {
		                int courseId = Integer.parseInt(courseIdInput);
		                // Update the course name in the database
		                saveChanges(courseId, newCourseName);
		            
		            } catch (NumberFormatException ex) {
		                Message.showErrorMessage("Invalid Course ID. Please enter a valid integer.");		          
		            }
		        } else {
		        Message.showErrorMessage("Course ID and updated course name are required. Please enter both.");		    
		        }
		    }
		});

		btnNewButton_1.setBounds(230, 115, 135, 23);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Delete Course");
		btnNewButton_2.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		    	if ("Student".equals(UserInfo.getUserRole()) || "Teacher".equals(UserInfo.getUserRole())) {
		    	    Message.showErrorMessage("Only admin can use this feature");
		    	    return;
		    	}
		        String courseIdInput = JOptionPane.showInputDialog("Enter the Course ID to delete:");
		        if (!AuthenticationHelper.isEmpty(courseIdInput)) {
		            try {
		                int courseId = Integer.parseInt(courseIdInput);
		                deleteCourse(courseId);
		            } catch (NumberFormatException ex) {
		                Message.showErrorMessage("Invalid Course ID. Please enter a valid integer.");
		            }
		        } else {
		            Message.showErrorMessage("Course ID is required. Please enter the Course ID.");
		        }
		    }
		});

		btnNewButton_2.setBounds(403, 115, 135, 23);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Dashboard");
		btnNewButton_3.setBounds(175, 11, 105, 23);
		contentPane.add(btnNewButton_3);
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				navigate.navigateToDashboard();
				dispose();
			}
		});
		
		JButton btnNewButton_4 = new JButton("Students");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				navigate.navigateToStudents();
				dispose();
			}
		});
		btnNewButton_4.setBounds(303, 11, 105, 23);
		contentPane.add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("Tutors");
		btnNewButton_5.setBounds(441, 11, 105, 23);
		contentPane.add(btnNewButton_5);
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				navigate.navigateToTeacher();
				dispose();
			}
		});
		
		JLabel lblNewLabel = new JLabel("Course");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel.setBounds(10, 15, 89, 14);
		contentPane.add(lblNewLabel);
		
	
	}
	
	   private DefaultTableModel getCourseData() {
	        DefaultTableModel model = new DefaultTableModel();
	        model.addColumn("CourseId");
	        model.addColumn("CourseName");

	        try (Connection conn = ConnectionHelper.createConnection();
	             PreparedStatement pstmt = conn.prepareStatement("SELECT course_id, course_name FROM finalAssemment.course");
	             ResultSet rs = pstmt.executeQuery()) {

	            while (rs.next()) {
	                int courseId = rs.getInt("course_id");
	                String courseName = rs.getString("course_name");
	                model.addRow(new Object[]{courseId, courseName});
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }

	        return model;
	    }
	   
	   private void saveChanges(int courseId, String newCourseName) {
		    // SQL statement to update the course name
		    String updateCourseSQL = "UPDATE finalAssemment.course SET course_name = ? WHERE course_id = ?";

		    try (Connection connection = ConnectionHelper.createConnection();
		         PreparedStatement pstmt = connection.prepareStatement(updateCourseSQL)) {

		        pstmt.setString(1, newCourseName);
		        pstmt.setInt(2, courseId);

		        int rowsAffected = pstmt.executeUpdate();

		        if (rowsAffected > 0) {
                 Message.showSuccessMessage("Course name updated successfully");	   	            
                 
		            DefaultTableModel model = getCourseData();
		            table.setModel(model);
		        } else {
		            Message.showErrorMessage("No course found with the provided ID");	        
		        }
		    } catch (SQLException e) {
		        e.printStackTrace();
		        Message.showErrorMessage("An error occurred while updating the course name");
		    }
		}	
	   
	// Delete course and related records
	   private void deleteCourse(int courseId) {
		   if (!isCourseExists(courseId)) {
		        Message.showErrorMessage("Course with the provided ID does not exist");
		        return;
		    }
	       try (Connection connection = ConnectionHelper.createConnection()) {
	           // 1. Delete records from the grade table associated with the modules of the course
	           String deleteGradeSQL = "DELETE FROM finalAssemment.grade WHERE module_id IN (SELECT module_id FROM finalAssemment.modules WHERE course_id = ?)";
	           try (PreparedStatement pstmt = connection.prepareStatement(deleteGradeSQL)) {
	               pstmt.setInt(1, courseId);
	               pstmt.executeUpdate();
	           }

	           // 2. Delete records from the teacher_module table associated with the modules of the course
	           String deleteTeacherModuleSQL = "DELETE FROM finalAssemment.teacher_module WHERE module_id IN (SELECT module_id FROM finalAssemment.modules WHERE course_id = ?)";
	           try (PreparedStatement pstmt = connection.prepareStatement(deleteTeacherModuleSQL)) {
	               pstmt.setInt(1, courseId);
	               pstmt.executeUpdate();
	           }

	           // 3. Delete records from the modules table associated with the course
	           String deleteModulesSQL = "DELETE FROM finalAssemment.modules WHERE course_id = ?";
	           try (PreparedStatement pstmt = connection.prepareStatement(deleteModulesSQL)) {
	               pstmt.setInt(1, courseId);
	               pstmt.executeUpdate();
	           }

	           // 4. Delete records from the course table itself
	           String deleteCourseSQL = "DELETE FROM finalAssemment.course WHERE course_id = ?";
	           try (PreparedStatement pstmt = connection.prepareStatement(deleteCourseSQL)) {
	               pstmt.setInt(1, courseId);
	               int rowsAffected = pstmt.executeUpdate();

	               if (rowsAffected > 0) {
	                   Message.showSuccessMessage("Course and related records deleted successfully");
	                   DefaultTableModel model = getCourseData();
	                   table.setModel(model);
	               } else {
	                   Message.showErrorMessage("No course found with the provided ID");
	               }
	           }
	       } catch (SQLException e) {
	           e.printStackTrace();
	           Message.showErrorMessage("An error occurred while deleting the course");
	       }
	   }
	   
	// Check if the course ID exists in the database
	   private boolean isCourseExists(int courseId) {
	       boolean exists = false;
	       try (Connection connection = ConnectionHelper.createConnection();
	            PreparedStatement pstmt = connection.prepareStatement("SELECT course_id FROM finalAssemment.course WHERE course_id = ?")) {
	           pstmt.setInt(1, courseId);
	           try (ResultSet rs = pstmt.executeQuery()) {
	               exists = rs.next();
	           }
	       } catch (SQLException e) {
	           e.printStackTrace();
	           Message.showErrorMessage("An error occurred while checking course existence");
	       }
	       return exists;
	   }



}
