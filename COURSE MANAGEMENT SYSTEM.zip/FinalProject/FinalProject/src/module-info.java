/**
 * 
 */
/**
 * 
 */
module FinalProject {
	requires java.desktop;
	requires java.sql;
}