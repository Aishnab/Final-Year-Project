//time
    setInterval(showTime, 1000);
    function showTime() {
        let time = new Date();
        let hour = time.getHours();
        let min = time.getMinutes();
        let sec = time.getSeconds();
        am_pm = "AM";
      
        if (hour > 12) {
            hour -= 12;
            am_pm = "PM";
        }
        if (hour == 0) {
            hr = 12;
            am_pm = "AM";
        }
      
        hour = hour < 10 ? "0" + hour : hour;
        min = min < 10 ? "0" + min : min;
        sec = sec < 10 ? "0" + sec : sec;
      
        let currentTime = hour + ":" 
                + min + ":" + sec + am_pm;
      
        document.getElementById("clock")
                .innerHTML = currentTime;
    }
    showTime();
    
// weather
const apiKey ="65a3ff2d57b3dac5f43378281d8f1e0f";
const apiUrl="https://api.openweathermap.org/data/2.5/weather?&units=metric&q=";
const searchBox =document.querySelector(".search input");
const searchBtn =document.querySelector(".search button");
const weatherIcon = document.querySelector(".weather-icon");

async function checkWeather(city){
    // Fetch weather data for the given city using the Open weather map API
    const response= await fetch(apiUrl + city + `&appid=${apiKey}`);
    // if the city is not found, display an error message and hide the weather information
    if(response.status == 404){
        document.querySelector(".error").style.display="block";
        document.querySelector(".weather").style.display="none";
    }
    // If the city is found, update the webpage with the weather information
    else{
        var data = await response.json();
        // extract weather information from Api response and update the HTML elements

        document.querySelector(".city").innerHTML = data.name;
        document.querySelector(".temp").innerHTML = Math.round(data.main.temp) + "°c" ;
        document.querySelector(".humidity").innerHTML = data.main.humidity + " %";
        document.querySelector(".wind").innerHTML = data.wind.speed + " km/h";
    // update the weather icon based on the weater condition
        if(data.weather[0].main=="Clouds"){
            weatherIcon.src ="images/clouds.png";
        }
        else if(data.weather[0].main=="Clear"){
            weatherIcon.src ="images/clear.png";
        }
        else if(data.weather[0].main=="Rain"){
            weatherIcon.src ="images/rain.png";
        }
        else if(data.weather[0].main=="Drizzle"){
            weatherIcon.src ="images/drizzle.png";
        }
        else if(data.weather[0].main=="Mist"){
            weatherIcon.src ="images/mist.png";
        }
    // display the weather information and hide the error message
    document.querySelector(".weather").style.display ="block";
    document.querySelector(".error").style.display="none";
    }
}

searchBtn.addEventListener("click",()=>{
    checkWeather(searchBox.value);
})