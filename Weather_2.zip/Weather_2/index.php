<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel = "stylesheet" type = "text/css" href = "./style.css">
    <title>Document</title>
</head>
<body>

<?php


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "aishna";

$conn = new mysqli($servername, $username, $password , $dbname);

// Check for errors
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create the database if it doesn't existQ
$sql = "CREATE DATABASE IF NOT EXISTS $dbname";
if ($conn->query($sql) === TRUE) {
    // echo "Database created successfully";
} else {
    echo "Error creating database: " . $conn->error;
}

// Select the database
$conn->select_db($dbname);

// Create the table
$sql = "DROP TABLE IF EXISTS weather";
$conn->query($sql);

$sql = "CREATE TABLE weather (
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    cityName  VARCHAR (255) ,
    temperature FLOAT(6,2) ,
    pressure FLOAT(6,2) ,
    humidity FLOAT(6,2) ,
    wind FLOAT(6,2) ,
    `description` VARCHAR(255) ,
    full_date VARCHAR(255)
)";

if ($conn->query($sql) === TRUE) {
    // echo "Table created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}



$cty_name = "Sunrise Manor";
$datas = json_decode(file_get_contents("https://history.openweathermap.org/data/2.5/history/city?q=".$cty_name."&type=hour&start=1682434889&cnt=400&appid=0997dc520ec4b21c2501f7d686b572f1"), true);

echo "<hr>";
echo "<hr>";
echo "<br>";

$seven_days_ago = strtotime('-8 days');
$prev_date = null;
$filtered_data = array();

foreach ($datas['list'] as $data) {
    $unix_timestamp = $data['dt'];
    $current_date = date("Y-m-d", $unix_timestamp);

    if ($current_date >= date('Y-m-d', $seven_days_ago) && $current_date <= date('Y-m-d')) {
        if ($current_date !== $prev_date) {
            $filtered_data[] = array(
                'temperature' => $data['main']['temp'],
                'pressure' => $data['main']['pressure'],
                'humidity' => $data['main']['humidity'],
                'wind' => $data['wind']['speed'],
                'description' => $data['weather']['0']['description'],
                'current_time' => date("H:i:s", $unix_timestamp),
                'full_date' => $current_date,
                'cityName' => $cty_name
            );
            $prev_date = $current_date;
        }
    }
}


foreach ($filtered_data as $data) {
    $sql = "INSERT INTO weather (temperature, pressure, humidity, wind, `description`, full_date, cityName) 
            VALUES ('" . $data['temperature'] . "', '" . $data['pressure'] . "', '" . $data['humidity'] . "', '" . $data['wind'] . "', '" . $data['description'] . "', '" . $data['full_date'] . "', '" . $data['cityName'] . "')"; 

    if ($conn->query($sql) === TRUE) {
        // Record inserted successfully
    } else {
        echo "Error inserting data: " . $conn->error;
    }
}

$getdata_sql = "SELECT * FROM weather ";

$req_all_data = $conn->query($getdata_sql); 
if ($req_all_data) {
    echo '<table>';
    echo '<thead>';
    echo '<tr>';
    echo '<th>ID</th>';
    echo '<th>City Name</th>';
    echo '<th>Temperature</th>';
    echo '<th>Pressure</th>';
    echo '<th>Humidity</th>';
    echo '<th>Wind</th>';
    echo '<th>Description</th>';
    echo '<th>Date</th>';
    echo '</tr>';
    echo '</thead>';
    echo '<tbody>';
    while ($data = mysqli_fetch_assoc($req_all_data)) {
        echo '<tr>';
        echo '<td>' . $data['id'] . '</td>';
        echo '<td>' . $data['cityName'] . '</td>';
        echo '<td>' . $data['temperature'] . '</td>';
        echo '<td>' . $data['pressure'] . '</td>';
        echo '<td>' . $data['humidity'] . '</td>';
        echo '<td>' . $data['wind'] . '</td>';
        echo '<td>' . $data['description'] . '</td>';
        echo '<td>' . $data['full_date'] . '</td>';
        echo '</tr>';
    }
    echo '</tbody>';
    echo '</table>';
}
?>

</body>
</html>